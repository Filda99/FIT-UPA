#! /bin/bash

pip3 install BeautifulSoup4
pip3 install requests
pip3 install urllib3==1.26.6
pip3 install re
pip3 install tqdm