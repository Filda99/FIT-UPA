#! /bin/bash

python3 -m venv superlativ_upa_proj3
source superlativ_upa_proj3/bin/activate

python3 -m pip install -r requirements.txt